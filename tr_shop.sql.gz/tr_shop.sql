-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `position` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id`, `page_id`, `cat_name`, `position`, `status`) VALUES
(1,	1,	'educational',	1,	1),
(2,	1,	'literature & fiction',	2,	1),
(3,	2,	'Apparel',	3,	1);

DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(120) NOT NULL,
  `images` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `image_status` tinyint(1) NOT NULL,
  `position` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `menus` (`id`, `menu_name`, `images`, `status`, `image_status`, `position`, `date`) VALUES
(1,	'Books',	'',	1,	1,	1,	'2015-10-11 12:22:55'),
(2,	'Kids',	'',	1,	0,	2,	'2015-10-11 12:39:42');

-- 2015-10-12 16:26:20
